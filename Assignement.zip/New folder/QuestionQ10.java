import java.util.*;
class Number
{
    int n;
    Number(int nn)
    {
        n=nn;
    }
    public int factorial(int a)
    {
        int i, fact=1;
        for(i=1; i<=a; i++)
        {
            fact=fact*i;
        }
        return fact;
    }
}
class Series extends Number
{
    int sum;
    Series(int n)
    {
        super(n);
        this.sum=0;
    }
    public void  calsum()
    {
        for (int i=1; i<=n; i++)
        {
            sum+=this.factorial(i);
        }
        System.out.println(sum);
    }
    public void display()
    {  
        System.out.println("The sum of the series :");
        this.calsum();
    }
}
class QuestionQ10
{
    public static void main(String [] args)
    { Scanner s=new Scanner(System.in);
      int num;
      num=s.nextInt();
       Series A=new Series(num);
      A.display();
    }
}