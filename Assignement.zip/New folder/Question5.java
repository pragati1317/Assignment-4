import java.lang.*;
import java.util.*;

class Record
{
    String[] name =new String[3];
    int [] rnk=new int[3];

    Record ()
    {  for (int i=0; i<3; i++)
       {
        this.name[i]=null;
        this.rnk[i]=0;
       }
        
    }
    public void readValues(Scanner s)
    {  for (int i=0; i<3; i++)
    {
         name[i]=s.next();
        rnk[i]=s.nextInt();
    }
       
    }
    public void display()
    { for (int i=0; i<3; i++)
      {
           System.out.println("Name :"+name[i]+" rnk:"+rnk[i]);
      }
       
    }
}

class Rank extends Record
{   
 int index;
 
  Rank()
  { 
     this.index=0;
  }
  public void highest()
  {  
      for (int i=0; i<(rnk.length-1); i++)
      {  
          if (rnk[index]>rnk[i+1])
          {     
                index=i+1;
          }
          
      }
  }
  public void display()
  {
      super.display();
      System.out.println("Highest Ranker");
      System.out.println("Name: "+name[index]+ " rank :"+rnk[index]);
  }
}
class Question5
{
    public static void main(String [] args)
    {
        Scanner s=new Scanner(System.in);
        Rank RecordStudent=new Rank();
          RecordStudent.readValues(s);
          RecordStudent.highest();
          RecordStudent.display();
    }
}