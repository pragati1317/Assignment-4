import java.lang.*;
import java.util.*;
class Number
{  

 public static int fact=0;
 public static int prevn=0;

    int n;
    
    Number(int nn)
    {
        n=nn;
    }
    public int factorial(int a)
    {
        if (prevn<a)
        {
              for (;prevn<=a; prevn++)
              {
                  fact=fact*prevn;
              }   
         }
         else
         {
             for (;prevn>a;prevn--)
             {
                fact=fact/prevn;
             }
         }
         prevn=a;
    return fact;
    }
}
//class 
class Question10
{
 
    public static void main (String [] args)
    {
       Number a=new Number(19);
       Number b=new Number (4);
       Number c=new Number(7);
       System.out.println(a.factorial(19) +" "+b.factorial(4)+ " "+c.factorial(7));
    }
}