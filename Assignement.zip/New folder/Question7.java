class Worker
{
    String Name;
    double Basic;

     Worker(String Name , double Basic)
     {
        this.Name=Name;
        this.Basic=Basic;
     }
    public void display()
    {
            System.out.println("Name of a Worker :"+Name);
            System.out.println("Basic payment :"+Basic);
    }
}
class Wages extends Worker
{
    int hrs;
    int rate;
    float wage;
  
    Wages(String Name , double Basic,int hrs, int rate, float wage)
    {
          super(Name,Basic);
          this.hrs=hrs;
          this.rate=rate;
          this.wage=wage;
    }
  public double overtime()
  { 
      return hrs*rate;

  }
  public void display()
  { double TotalAmount=(this.overtime() +Basic);
     super.display();
     System.out.println("Total amount :"+TotalAmount) ;

  }
}

class Question7
{
    public static void main(String [] args)
    {
        Wages w1= new Wages("priyansh",4009.95,9,79,1200);
         System.out.println(w1.overtime());
        // System.out.println(w1.display());
    }
}
