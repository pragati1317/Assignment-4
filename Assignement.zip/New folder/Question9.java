// Q9. Create a java program based on the following specifications:
// A superclass Stock has to be defined to store the details of the stock of a retail store. Also
// define a subclass Purchase to store the details of the items purchased with the new rate and
// update the stock. Some of the members of the classes are given below:
// Class name: Stock
// Data members/instance variables:

// item: to store the name of the item
// qt: to store the quantity of an item in stock
// rate: to store the unit price of an item
// amt: to store the net value of the item in stock
// Member functions:
// Stock (...): parameterized constructor to assign values to the data members
// void display(): to display the stock details
// Class name: Purchase
// Data members/instance variables:
// pqty: to store the purchased quantity
// prate: to store the unit price of the purchased item
// Member functions/ methods:
// Purchase(...): parameterized constructor to assign values to the data members of both classes
// void update (): to update stock by adding the previous quantity by the purchased quantity and
// replace the rate of the item if there is a difference in the purchase rate. Also, update the current
// stock value as (quantity * unit price)
// void display(): to display the stock details before and after updation.
// 9.1. Specify the class Stock, giving details of the constructor() and void display().
// 9.2. Using the concept of inheritance, specify the class Purchase, giving details of the
// constructor(), void update() and void display(). Create a main class to test the methods.
import java.lang.*;

class Stock
{
    String item;
    int qt;
    double rate;
     int  amt ;
    Stock(String item,int qt,double rate,int amt){
        this.item=item;
        this.qt=qt;
        this.rate=rate;
          this.amt=amt; 
    }
    public void  display()
    {
          System.out.println("Item :"+item+" quantity of that item :"+qt+" Unit price of that Quantity :"+rate+" amount of that item :"+amt);
    }
}
class Purchase extends Stock
{
    int pqty;
    double prate;

    Purchase(String item,int qt,double rate,int amt,int pqty, double prate)
    {   super(item,qt,rate,amt);
         this.pqty=pqty;
         this.prate=prate;
    }
    public void update()
    {
        qt+=pqty;
        if((prate-rate)!=0)
        {
            rate=prate;
        }
        amt-=amt;
        amt+=(qt*rate);

    }
    public void display()
    {
       super.display();
       System.out.println("New Stock");
       this.update();
       System.out.println("Item :"+item+" , Qunatity :"+qt+" rate :"+rate+" amount of that item :"+amt);
    }
}
class Question9
{
    public static void main(String [] args)
    {
        Purchase p=new Purchase("Maggi ",23, 2, 20,22,1.8);
        p.display();
    }
}