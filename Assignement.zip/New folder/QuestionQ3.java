import java.util.Scanner;
public class QuestionQ3{
	public static void main(String args[]){
        int arr[] = new int[20];

   // Array initialization is hidden     
   //Write the code here.
 try{
    for(int i=0; i<arr.length; i++)
    { arr[i]=65;
    }
   Scanner s=new Scanner(System.in);
    //Enter the index whixh element you want to print
   int index;
   index=s.nextInt();
   //printing a index array element
     if (index<arr.length)
     { System.out.println(arr[index]);
     }
  } 
  catch(Exception e)
  { System.out.println(e.getMessage());
  }
    }
}