import java.lang.*;

class Plane
{
  double x1;
  double y1;
  Plane(double nx, double ny )
  {
      x1=nx;
      y1=ny;
  }
  public void show()
  {
      System.out.println("x1-cordinate :"+x1+" , y1-cordinate : "+y1);

  }
}
class Circle extends Plane{
    double x2;
    double y2;
    double radius;
    double area;
    Circle (double x1, double y1,double x2,double y2, double radius)
    {
       super(x1,y1);
       this.y2=y2;
       this.x2=x2;
       this.radius=radius;
       
    }
    public void findRadius()
    {
        double result=(Math.sqrt((x1-x2)*(x1-x2)-(y1-y2)*(y1-y2))) /2;
        System.out.println("Length of a plane is : " +result);
    }
    public void findArea()
    {   area=(22/7)*radius*radius;
          System.out.println("Total Area :"+area);
    }
    public void show()
  {  super.show();
     System.out.println("Another point cordinate are ");
     System.out.println("x-cordinate is :"+x2+"y-cordinate is :"+y2);
      this.findRadius();
      this.findArea();
  }
}

class Question8
{
    public static void main(String [] args)
    {
        Circle objA=new Circle(2,5,7,1,12);
        objA.show();
    }
}