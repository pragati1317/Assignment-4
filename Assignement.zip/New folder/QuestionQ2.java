import java.util.*;
class QuestionQ2
{
    public static void main(String[] args)
    {    Scanner s=new Scanner(System.in);
         CreditCard A=new CreditCard("priyanka","A367#f123", 123,"31 november");
         A.futherCreditdetails(true,2,2300000,30000);
         int amount=s.nextInt();

         A.transact(amount);
         int cardtype;
         System.out.println("Enter the credit card type in numbers");
         cardtype=s.nextInt();
         A.Discount(cardtype);
         A.Display(A);
    }
}
class CreditCard
{    String name;
     String cardNo;
     boolean enabled;
     int pin;
     String expiryMonth;
     int cardType;

    int currentCredit;
    int creditLimit;

    CreditCard(String name,String cardNo, int pin,String expiryMonth )
    {
        this.name=name;
        this.cardNo=cardNo;
        this.pin=pin;
        this.expiryMonth=expiryMonth;
        
    }
void futherCreditdetails(boolean enabled,int cardType,int currentCredit,int creditLimit)
        {
            this.enabled=enabled;
            this.cardType=cardType;
            this.currentCredit=currentCredit;

            this.creditLimit=creditLimit;

            

        }
    void changePin(int newPin)
    {
        pin=newPin;
        System.out.println("newPin"+pin);
    }
   void transact(int amt)
    {
       this.check(pin);
       if(amt<this.creditLimit)
       { 
           currentCredit-=amt;
          System.out.println("valid");
       }
       else
       {
           System.out.println("not valid");
       }
    }
    void Discount(int cardType)
    {
        if (cardType==1)
        {
            System.out.println("Commpany will going to offer you 3% discount");
        }
        else if(cardType==2)
        {
            System.out.println("company will going to offer you 2% discount ");

        }
        else if(cardType==3)
        {
            System.out.println("company will going to offer you 1% discount");
        }
        else
        {
            System.out.println("Not valid cardtype");
        }
    }
    void check(int currentpin)
    {
        if(pin==currentpin)
        {
            System.out.println("valid pin");
        }
        else
        {
            System.out.println("not vaild pin");
        }
    }
    
    void Display(CreditCard obj)
    {
       System.out.println(obj.name+" Card No. "+obj.cardNo+"  cardType "+obj.cardType+" Current amount  "+obj.currentCredit+"  Credit card limit "+obj.creditLimit+" Expiry month of card"+obj.expiryMonth);
    }
     void changeCardStatus(boolean currentStatus)
    {  

          this.enabled=currentStatus;

        //System.out.println(""+enabled);
    }
   
}