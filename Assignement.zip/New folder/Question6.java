import java.util.*;
import java.lang.*;

class Student
{
    String name;
    String sex;
    int age;
    public void inpdetails(Scanner s)
    {
        name=s.nextLine();
        sex=s.nextLine();
        age=s.nextInt();
    }
    public void show()
    {
        System.out.println("Name :"+name+" , sex:"+sex+", age: "+age);
    }
}
class Marks extends Student
{
    int regum;
    int marks;
    String subject;

    public void inpdetails(Scanner s)
    {
       super.inpdetails(s);
        regum=s.nextInt();
        marks=s.nextInt();
        subject=s.next();
    }
    public void show()
    {
        super.show();
        System.out.println("Registration Number :"+regum+" Marks :"+marks+"  subject :"+ subject);
    }
}
class Question6
{
    public static void main(String [] args)
    {
        Scanner s=new Scanner(System.in);
        Marks s1=new Marks();
        s1.inpdetails(s);
        s1.show();
        
    }
}
