class Employee
{
    String Dept;
    int HRA;
    int basicSalary;
    int Allowance;
 
 void Allowance (String Dept)
 {
 if(Dept=="1")
 {
   Allowance=1500;   
 }
 else if(Dept=="2")
 {
     Allowance=2500;
 }
 else if(Dept=="3")
 {
     Allowance=3500;
 }
 }
 Employee(String Dept,int basicSalary)
 {
     this.Dept=Dept;
     this.basicSalary=basicSalary;
 }

void Salary ()
{ 
    HRA=((40*basicSalary)/100);
   int Salary=basicSalary+ HRA+ Allowance;
   System.out.println("Total-salary"+Salary);
}
}
class QuestionQ1
{
    public static void main (String args[])
    {
        Employee a=new Employee("1",35000);
        a.Allowance("1");
        a.Salary();
         Employee b=new Employee("2",3000);
     b.Allowance("2");
        b.Salary();
         Employee c=new Employee("2",25000);
        c.Allowance("3");
        c.Salary();


    }
}