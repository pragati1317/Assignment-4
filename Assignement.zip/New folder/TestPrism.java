import java.lang.*;
import java.util.Scanner;
class Prism 
{
    double length;
    double width;
    double height;

    Prism(double l, double w, double h)
    {
        l=length;
        w=width;
        h=height;

    }
    Prism()
    {
        length=0.0;
        width=0.0;
        height=0.0;
    }
   public void setPrism(Scanner s, Prism p)
    {
        p.length=s.nextDouble();
        p.width=s.nextDouble();
        p.height=s.nextDouble();
    }
  public void topArea()
  {
    System.out.println("TopArea of a prism"+" :"+ length*width);
  }
  public void  bottomArea()
  {
      System.out.println("BottomArea of a prism "+" :"+ length*width);
  }
  public void leftArea()
  {
       System.out.println("leftArea of a Prism"+ " : "+height*width);
  }
  public   void rightArea()
  {
      System.out.println("rightArea of a prism is :"+ height*width);
  } 
  public void frontArea()
  {
      System.out.println("Front Area of a prism is :"+ height*length);
  }
  public void backArea()
  {
      System.out.println("Back area of a prism is :"+ height*length);
  }
  public double area()
      {
         return 2*(length*width+height*width+height*length);
      }
  

}

class TestPrism
{
    public static void main(String [] args)
    {
         Scanner s=new Scanner(System.in);
         Prism p=new Prism();
         p.setPrism(s,p);
         p.topArea();
         p.bottomArea();
         p.leftArea();
         p.rightArea();
         p.frontArea();
         p.backArea();
         p.bottomArea();

         System.out.println("Total area of a prism is :"+p.area());
    }
}
