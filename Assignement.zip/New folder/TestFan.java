import java.lang.*;

class Fan
{
    private String fanType;
    private String manufacture;
   private String model;
   private  Boolean isOn;
   public enum Speed
   {
      
   }
   public void setFan(enum Speed)
   {
       
   }

}
class TestFan
{
    public static void main(String [] args)
    {
        Scanner s=new Scanner(System.in);
        
    }
}